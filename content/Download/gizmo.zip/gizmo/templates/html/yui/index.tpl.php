<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
 "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
	<title><?php echo $title ?></title>
	<link rel="stylesheet" href="http://yui.yahooapis.com/2.7.0/build/reset-fonts-grids/reset-fonts-grids.css" type="text/css">
	<link rel="stylesheet" href="http://yui.yahooapis.com/2.7.0/build/base/base.css" type="text/css">
</head>
<body>
<div id="doc" class="yui-t1">
   <div id="hd" role="banner"><h1><a href="/"><?php echo $title ?></a></h1></div>
   <div id="bd" role="main">
	<div id="yui-main">
	<div class="yui-b"><div class="yui-g">
		<!-- YOUR DATA GOES HERE -->
	
		<?php echo $fs->render('files') ?>

	</div>
</div>
	</div>
	<div class="yui-b">
		<!-- YOUR DATA GOES HERE -->
		<?php foreach ($fs->getMenu() as $link): ?>
			<li><?php echo $link ?></li>
		<?php endforeach ?>	
	</div>
	
	</div>
	<div id="ft" role="contentinfo">
		<a rel="license" href="http://creativecommons.org/licenses/by/3.0/"><img alt="Creative Commons License" style="border-width:0" src="http://i.creativecommons.org/l/by/3.0/80x15.png" /></a> This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by/3.0/">Creative Commons Attribution 3.0 Unported License</a>.	
	</div>
</div>
</body>
</html>
