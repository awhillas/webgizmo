<?php

class FSFilterIterator extends FilterIterator
{
	private $_filters = array();
	
	// TODO: replace this with some Reflection?
	private $_valid_filters = array(
		'isDot', 'isDir', 'isFile', 'isReadable', 'isWritable', 'isLink',	// Booleans
		'getSize', 'getMTime', 'getCTime', 'getATime', 'getBasename', 'getFilename'	// for string comparison
	);

	public function __construct($iterator, $filters = array())
	{
		parent::__construct($iterator);
		
		$this->_filters = $filters;
		
		$this->isDot = false;		
	}
	
	/**
	 * Implement abstract function from FilterIterator
	 *
	 * @return boolean
	 **/
    public function accept()
    {	
		$current = $this->current();
//		print_r($current);		
		foreach($this->_filters as $filter => $value)
			if(method_exists($current, $filter) and $current->$filter() != $value)
				return false;
		
        return true;
    }	

	function __set($filter, $value)
	{
		if(strpos($filter, 'is') !== 0 and strpos($filter, 'get') !== 'get')
			$filter = 'get'.$filter;
		
		if(in_array($filter, $this->_valid_filters))
			$this->_filters[$filter] = $value;
	}
}