<?php
// Check PHP version is high enough
if(version_compare(PHP_VERSION, '5.0.0') <= 0)
	trigger_error('You need at least PHP 5.3 to use FS-CMS! You have version '.PHP_VERSION, E_ERROR);

// Make sure our Classes get included automatically
set_include_path(get_include_path().PATH_SEPARATOR.dirname(__FILE__));
// Content classes...
set_include_path(get_include_path().PATH_SEPARATOR.dirname(__FILE__).'/contenttypes/');

spl_autoload_extensions('.class.php');
spl_autoload_register();	// Use default autoload implementation coz its fast

// Root paths on the server. 
// Can be overriden in the index.php file so can be shared by multipule websites.
// TODO: perhap wrap these up in a Class?
if (!defined('WEB_ROOT')) 		define('WEB_ROOT', 		dirname($_SERVER['SCRIPT_FILENAME']));
if (!defined('FS_CMS_PATH'))	define('FS_CMS_PATH', 	dirname(__FILE__));
if (!defined('INCLUDES_PATH'))	define('INCLUDES_PATH',	FS_CMS_PATH.'/includes');
if (!defined('CONTENT_DIR')) 	define('CONTENT_DIR', 	'/content');
if (!defined('TEMPLATES_DIR'))	define('TEMPLATES_DIR',	'/templates');
// mod_rewrite is on
if (!defined('REWRITE_URLS'))	define('REWRITE_URLS', true); 

// Boring stuff
/**
 * Character set used, used for htmlentities() function and HTML document header
 * @var	String
 * @see http://php.net/manual/en/function.htmlentities.php
 * @see FS::strip
 **/
if (!defined('CHAR_ENCODING'))	define('CHAR_ENCODING',	'UTF-8');

////////// Content Variables
if (!defined('SITE_TITLE'))	define('SITE_TITLE', $_SERVER['SERVER_NAME']);
if (!defined('THEME_DIR'))		define('THEME_DIR',		'/default');

/**
* FS class
* 
* File System Content Management System. The core of Gizmo.
* It was called FS as Gizmo was original called FS-CMS.
* Is a Singleton, with the static get() method. 
* @todo Put some more Exception throwing + handling in
*/
class FS
{
	/**
	 * Stactic copy of self. Used in the Singleton design pattern.
	 * @var FS
	 */
	private static $_instance;
	
	/**
	 * List of files to ignore
	 * Would be nice if arrays could be in Class Constants :(
	 * @var Array
	 */
	private $EXCLUDE_FILES = array('.', '..', '.DS_Store', 'Thumbs.db');
	
	/**
	 * List of Path objects.
	 * Used to store variables by __get & __set
	 * @var Array
	 */
	private $_paths = array();
		
	/**
	 * Array of Content objects
	 * @var Array
	 */
	private $content = Array();
	
	function __construct($content_path = CONTENT_DIR, $templates_path = TEMPLATES_DIR)
	{
		// __set() should turn these into Path objects and store them in $this->_paths.
		$this->contentRoot = WEB_ROOT . $content_path;
		$this->templatesRoot = WEB_ROOT . $templates_path;
		// current virtual path
		$this->path = WEB_ROOT . CONTENT_DIR . FS::getPath()->get();
	}
	
	public function __set($name, $path) 
	{
		if(!isset($this->_paths[$name]))
			$this->_paths[$name] = new Path($path);
	}
	
	public function __get($name)
	{
		if(isset($this->_paths[$name]))
			return $this->_paths[$name];

		// TODO: make this throw and exception instead?
		$trace = debug_backtrace();
		trigger_error(
			'Undefined property via __get(): ' . $name .
			' in ' . $trace[0]['file'] .
			' on line ' . $trace[0]['line'],
			E_USER_NOTICE);
		return null;
	}
	
	/**
	 * So when this object is used as a function the 'parse' method is invoked
	 * Handy in the Savant templates where an instance of FS is already instantiated
	 * 
	 * @see FS::parse()
	 */
	public function __invoke($files_list) 
	{
		return $this->parse($files_list);
	}
	
	/**
	 * Build array of FileContent objects from an Array of FileInfo objects.
	 * 
	 * @param	Array	of SplFileInfo objects
	 * @return 	Array	Array of FileContent
	 */
	public function parse($files_list)
	{
		$out = array();

		foreach ($files_list as $File)	
		{
			if (!in_array($File->getFilename(), $this->EXCLUDE_FILES))
			{
				$out[] = FileContent::Factory($File);
			}
		}		
		return $out;
	}

	/**
	 * Instantiate the Template Engine and find all the appropriate templates to give it.
	 * @see http://phpsavant.com/
	 * @see http://devzone.zend.com/article/9075
	 */
	private function getTemplate($format = 'html')
	{
		$tpl_path = $this->templatesRoot->get() .'/'. $format . THEME_DIR;
		
		if(file_exists($tpl_path))
		{
			// Using Savant3 template system.
			require INCLUDES_PATH.'/Savant3/Savant3.php';

			// set options
			$options = array(
				'template_path' => $tpl_path,
				'exceptions'    => true,
				'extract'       => true
			);

			// initialize template engine
			return new Savant3($options);
		}
		else
		{
			trigger_error('Template could not be found: '.$tpl_path, E_USER_ERROR);
			return false;
		}
	}

	/**
	 * Handle HTTP request
	 * @todo Send some HTTP headers here with the right mimetype and cacheing info...?
	 */
	public function HttpRequest($format = 'html')
	{
		if($this->path->is())
		{
			if($tpl = $this->getTemplate($format))
			{
				$tpl->fs = $this;
				$tpl->here = $this->path;
				$tpl->title = SITE_TITLE;

				$tpl->display('index.tpl.php');
			}
		}
	}
	
	/**
	 * @return Array	List of html links to the top level Content Directories.
	 * @todo Make this more general so sub-menus are possible.
	 */
	public function getMenu()
	{
		$out = array();

		foreach (array_keys($this->getContentTree()) as $dir) 
		{
			$url = (REWRITE_URLS) ? "/$dir" : "?path=/$dir";
			
			$class = ('/'.$dir == FS::getPath()) ? ' class="Selected" ' : '';
			
			$out[] = "<a href=\"$url\"$class>{$this->clean($dir)}</a>";
		}

		return $out;
	}

	/**
	 * Get the Content tree starting at the given virtual path
	 * 
	 * @param	String	Virtual content path to start from. Should begin with a '/'.
	 * @param	Boolean	Only return Directories, ignore files?
	 * @return 	Array	Multidimensional array representing the directory structure.
	 **/
	public function getContentTree($virtual_root = '', $only_dirs = true)
	{
		return FS::getDirectoryTree($this->contentRoot.$virtual_root);
	}
	
	
	// / / / / / / / / / / / / / / / / / / / / / / / / /
	// Static funcitons
	// / / / / / / / / / / / / / / / / / / / / / / / / /

	/**
	 * Strip leading numbers + underscore from the given string
	 * + escape HTML special characters
	 * @todo make this work (with reg. expr.'s?)
	 */
	public static function clean($value = '')
	{
		// Strip 00_ from the beginning of a file name
		$value = preg_replace('/^[0-9]{2}[_]{1}/', '', $value);
		
		return htmlentities($value, ENT_NOQUOTES, CHAR_ENCODING);
	}
	
	/**
	 * Singleton constructor function.
	 *
	 * @return void
	 **/
	public static function get($content_path = CONTENT_DIR, $templates_path = TEMPLATES_ROOT) 
	{
        if (!self::$_instance)
        {
            self::$_instance = new FS($content_path, $templates_path);
        }
        return self::$_instance;
	}
	
	/**
	 * 'bare bones' recursive method to extract directories and files
	 * 
	 * @param	String	Directory to start scanning from
	 * @param	Boolean	Only return Directories, ignore files?
	 * @return 	Array	
	 * @author	Dustin
	 * @see http://de2.php.net/manual/en/function.scandir.php#88006
	 **/
	public static function getDirectoryTree($outerDir, $only_dirs = true)
	{
		$dirs = array_diff( scandir( $outerDir ), Array( ".", ".." ) );
		
		$out = Array();
		
		foreach( $dirs as $d )
			if( is_dir($outerDir."/".$d) ) 
				$out[ $d ] = FS::getDirectoryTree( $outerDir."/".$d );
			elseif(!$only_dirs)
				$out[ $d ] = $d;
		
		return $out;		
	}
	
	/**
	 * Get the CGI 'path' variable value
	 *
	 * @return String	The current virtual path (relative to the base URL)
	 */
	public static function getPath()
	{
		return (isset($_GET['path'])) ? new Path($_GET['path']): new Path('/');
	}
	
	/**
	 * @return Array	of FileContent objects the the current virtual path.
	 **/
	public function getContent($filter = null)
	{
		// Use the Path object to get a filtered list of files (files only here).
		// NB: Local vaiable $here = $this->path in the template
//		$list = $this->path->query($filter);
		$list = $this->path->getIt($filter);	// query is just a wrapper for getIt() anyway

		// Parse the list of files, wraping each in one of the FileContent objects based on its extention. 
		// NB: Local variable $fs = $this in the template.
		return $this->parse($list);
	}
	
	/**
	 * Default render the current Virtual path's folder contents.
	 * 
	 * This is more a connivence function and is more of an example. More complex 
	 * filtering and rendering control can be achieved by doing this in the template
	 * itself, and is in fact the idea behind the template design.
	 * 
	 * For example: one might want to filter out everything except images and use only
	 * their paths in some Flash gallery widget one part if the template and then grab only
	 * the .text files and use the default rendering on another part (column say).
	 * 
	 * @param	String	$only	Filter out everything except 'files' or 'folders' 
	 * @return 	String	HTML
	 **/
	public function render($only = 'files', $format = 'html')
	{
		$out = '';
		
		// Build filter array. See Path::getIt() for more complex examples. 
		switch($only)
		{
			case 'files':
				$filter = array('isFile' => true);
				break;
			
			case 'folders':
				$filter = array('isDir' => true);
				break;
		}
		
		// Get the content and render each
		foreach($this->getContent($filter) as $file) 
			$out .= $file->render($format);
		
		return $out;
	}
}

