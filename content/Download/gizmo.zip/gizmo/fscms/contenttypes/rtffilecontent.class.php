<?php
include_once(INCLUDES_PATH.'/rtf2html/functions_parce.php');

class RTFFileContent extends TextFileContent
{	
	protected $_display_full_filename = false;
	
	function __toString()
	{
		return $this->convert();
	}
	
	function convert()
	{
		$cont = $this->_content;
		
		if (preg_match("/^".preg_quote("{\\rtf")."/msi",$cont)) {

			$sample = preg_replace("/ \\\/msi","\\",$cont);
			$sample = preg_replace("/[\n\r]/msi","",$cont);
			$sample = "{".substr($sample,strpos($sample,"\\pard"));

//			$timer = new ArkTimer;

			$c_fin = mkl($sample);
			$c_fin = $c_fin[0];

			$htm = new RtfHtml;
			$htm->parce_levels($c_fin);

			return $htm->final_html;
		}
		else {
			trigger_error( "This file is not an RTF");
		}
	}
}