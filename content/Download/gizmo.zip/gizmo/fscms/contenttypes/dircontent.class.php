<?php
class DirContent extends FileContent
{	
	function html($format = 'xhtml1.1')
	{
		return '<a href="?path='. FS::getPath() . $this .'" class="GenericFileContent">'. $this .'</a>';
	}
}