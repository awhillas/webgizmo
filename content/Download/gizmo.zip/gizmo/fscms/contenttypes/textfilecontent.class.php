<?php
/**
 * Text files
 * 
 * Will try to handle whitespace nicely.
 *
 * @package Web Gizmo
 * @author Alexander R B Whillas
 **/
class TextFileContent extends FileContent
{	
	/**
	 * Raw contents of the Text file read in by the constructor
	 * @var	String
	 */
	protected $_content;
	
	/**
	 * Should the default HTML rendering display the full filename or a cleaned version?
	 * @var	Boolean
	 * @see TextFileContent::renderHTML
	 */
	protected $_display_full_filename = false;
	
	function __construct($file)
	{
		parent::__construct($file);
				
		$this->_content = file_get_contents($this->get()->getRealPath(), FILE_TEXT);
	}
	
	/**
	 * @todo Should try to parse the white space and wrap in DIV
	 */
	function html($format = 'xhtml1.1')
	{
		return $this->renderHTML($format = 'xhtml1.1', "<p>$this->_content</p>");
	}
	
	/**
	 * Function to do the standard text file handling behaviour so that descendants can optionally call it 
	 */
	protected function renderHTML($format = 'xhtml1.1', $content)
	{
		$class_name = get_class($this);
		
		$title = ($this->_display_full_filename) 
			? $this->get()->getFilename() 
			: $this->getCleanName();
				
		return "
		<div class=\"$class_name\">
			<h2 class=\"FileName\">$title</h2>
			<div class=\"Content\">$content</div>
		</div>
		";
	}
	
	function __toString()
	{
		return $this->_content;
	}
}
